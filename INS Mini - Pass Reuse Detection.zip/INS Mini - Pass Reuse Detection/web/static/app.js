const state = {
  summary: null,
};

const elements = {
  accountForm: document.querySelector("#accountForm"),
  service: document.querySelector("#service"),
  username: document.querySelector("#username"),
  password: document.querySelector("#password"),
  togglePassword: document.querySelector("#togglePassword"),
  saveStatus: document.querySelector("#saveStatus"),
  riskStatus: document.querySelector("#riskStatus"),
  totalAccounts: document.querySelector("#totalAccounts"),
  uniquePasswords: document.querySelector("#uniquePasswords"),
  duplicateGroups: document.querySelector("#duplicateGroups"),
  atRiskAccounts: document.querySelector("#atRiskAccounts"),
  duplicateList: document.querySelector("#duplicateList"),
  accountsTable: document.querySelector("#accountsTable"),
  refreshButton: document.querySelector("#refreshButton"),
  scanButton: document.querySelector("#scanButton"),
  reportButton: document.querySelector("#reportButton"),
  reportCard: document.querySelector("#reportCard"),
  reportName: document.querySelector("#reportName"),
  downloadReport: document.querySelector("#downloadReport"),
  reportPreview: document.querySelector("#reportPreview"),
};

async function requestJson(url, options = {}) {
  const response = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
    ...options,
  });

  const payload = await response.json();
  if (!response.ok) {
    throw new Error(payload.error || "Request failed.");
  }

  return payload;
}

function setIconState() {
  if (window.lucide) {
    window.lucide.createIcons();
  }
}

function setStatus(element, text, tone = "") {
  element.textContent = text;
  element.className = `status-pill ${tone}`.trim();
}

function formatDate(value) {
  if (!value) {
    return "";
  }

  return value.replace("T", " ");
}

function renderMetrics(metrics) {
  elements.totalAccounts.textContent = metrics.totalAccounts;
  elements.uniquePasswords.textContent = metrics.uniquePasswords;
  elements.duplicateGroups.textContent = metrics.duplicateGroups;
  elements.atRiskAccounts.textContent = metrics.atRiskAccounts;
}

function renderRiskStatus(metrics) {
  if (metrics.totalAccounts === 0) {
    setStatus(elements.riskStatus, "No Data");
    return;
  }

  if (metrics.atRiskAccounts === 0) {
    setStatus(elements.riskStatus, "Clear", "good");
    return;
  }

  setStatus(elements.riskStatus, `${metrics.atRiskAccounts} At Risk`, "danger");
}

function renderDuplicates(groups) {
  elements.duplicateList.className = "duplicate-list";
  elements.duplicateList.innerHTML = "";

  if (!state.summary || state.summary.metrics.totalAccounts === 0) {
    elements.duplicateList.className = "duplicate-list empty-state";
    elements.duplicateList.innerHTML = `
      <i data-lucide="shield"></i>
      <p>No account data loaded.</p>
    `;
    setIconState();
    return;
  }

  if (groups.length === 0) {
    elements.duplicateList.className = "duplicate-list empty-state";
    elements.duplicateList.innerHTML = `
      <i data-lucide="shield-check"></i>
      <p>No password reuse detected.</p>
    `;
    setIconState();
    return;
  }

  const fragment = document.createDocumentFragment();

  groups.forEach((group) => {
    const groupNode = document.createElement("article");
    groupNode.className = "duplicate-group";
    groupNode.innerHTML = `
      <div class="duplicate-group-header">
        <span>Duplicate Group ${group.groupNumber}</span>
        <span>${group.accounts.length} accounts</span>
      </div>
      <div class="duplicate-members"></div>
    `;

    const membersNode = groupNode.querySelector(".duplicate-members");
    group.accounts.forEach((account) => {
      const memberNode = document.createElement("div");
      memberNode.className = "duplicate-member";
      memberNode.innerHTML = `
        <div>
          <strong>${escapeHtml(account.service)}</strong>
          <span>${escapeHtml(account.username)}</span>
        </div>
        <span class="risk-badge danger">Reused</span>
      `;
      membersNode.appendChild(memberNode);
    });

    fragment.appendChild(groupNode);
  });

  elements.duplicateList.appendChild(fragment);
}

function renderAccounts(accounts) {
  elements.accountsTable.innerHTML = "";

  if (accounts.length === 0) {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td colspan="5">
        <span>No account records yet.</span>
      </td>
    `;
    elements.accountsTable.appendChild(row);
    return;
  }

  accounts.forEach((account) => {
    const row = document.createElement("tr");
    const statusTone = account.atRisk ? "danger" : "good";
    const statusText = account.atRisk ? "Reused" : "Unique";

    row.innerHTML = `
      <td>
        <strong>${escapeHtml(account.service)}</strong>
        <span>Updated ${escapeHtml(formatDate(account.updatedAt))}</span>
      </td>
      <td><span>${escapeHtml(account.username)}</span></td>
      <td><span>${escapeHtml(account.hashPreview)}</span></td>
      <td><span class="risk-badge ${statusTone}">${statusText}</span></td>
      <td class="action-column">
        <button class="delete-button" type="button" title="Delete record" aria-label="Delete ${escapeHtml(account.service)} record" data-record-id="${escapeHtml(account.recordId)}">
          <i data-lucide="trash-2"></i>
        </button>
      </td>
    `;

    elements.accountsTable.appendChild(row);
  });

  setIconState();
}

function renderSummary(summary) {
  state.summary = summary;
  renderMetrics(summary.metrics);
  renderRiskStatus(summary.metrics);
  renderDuplicates(summary.duplicateGroups);
  renderAccounts(summary.accounts);
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function showToast(message, isError = false) {
  const existingToast = document.querySelector(".toast");
  if (existingToast) {
    existingToast.remove();
  }

  const toast = document.createElement("div");
  toast.className = `toast ${isError ? "error" : ""}`.trim();
  toast.textContent = message;
  document.body.appendChild(toast);

  window.setTimeout(() => {
    toast.remove();
  }, 3200);
}

async function refreshSummary() {
  const payload = await requestJson("/api/summary");
  renderSummary(payload);
}

async function handleSubmit(event) {
  event.preventDefault();
  setStatus(elements.saveStatus, "Saving", "warning");

  try {
    const payload = await requestJson("/api/accounts", {
      method: "POST",
      body: JSON.stringify({
        service: elements.service.value,
        username: elements.username.value,
        password: elements.password.value,
      }),
    });

    renderSummary(payload.summary);
    elements.accountForm.reset();
    setStatus(elements.saveStatus, payload.updated ? "Updated" : "Stored", "good");
    showToast(payload.message);
  } catch (error) {
    setStatus(elements.saveStatus, "Error", "danger");
    showToast(error.message, true);
  }
}

async function handleDelete(event) {
  const button = event.target.closest("[data-record-id]");
  if (!button) {
    return;
  }

  const recordId = button.dataset.recordId;
  button.disabled = true;

  try {
    const payload = await requestJson(`/api/accounts/${encodeURIComponent(recordId)}`, {
      method: "DELETE",
    });
    renderSummary(payload.summary);
    showToast("Account record deleted.");
  } catch (error) {
    button.disabled = false;
    showToast(error.message, true);
  }
}

async function handleReport() {
  elements.reportButton.disabled = true;

  try {
    const payload = await requestJson("/api/reports", {
      method: "POST",
      body: "{}",
    });

    elements.reportCard.hidden = false;
    elements.reportName.textContent = payload.fileName;
    elements.downloadReport.href = payload.downloadUrl;
    elements.reportPreview.textContent = payload.preview;
    showToast("Report generated.");
  } catch (error) {
    showToast(error.message, true);
  } finally {
    elements.reportButton.disabled = false;
  }
}

function togglePasswordVisibility() {
  const isHidden = elements.password.type === "password";
  elements.password.type = isHidden ? "text" : "password";
  elements.togglePassword.title = isHidden ? "Hide password" : "Show password";
  elements.togglePassword.setAttribute("aria-label", isHidden ? "Hide password" : "Show password");
  elements.togglePassword.innerHTML = `<i data-lucide="${isHidden ? "eye-off" : "eye"}"></i>`;
  setIconState();
}

function bindEvents() {
  elements.accountForm.addEventListener("submit", handleSubmit);
  elements.accountsTable.addEventListener("click", handleDelete);
  elements.reportButton.addEventListener("click", handleReport);
  elements.togglePassword.addEventListener("click", togglePasswordVisibility);
  elements.refreshButton.addEventListener("click", () => {
    refreshSummary()
      .then(() => showToast("Dashboard refreshed."))
      .catch((error) => showToast(error.message, true));
  });
  elements.scanButton.addEventListener("click", () => {
    refreshSummary()
      .then(() => showToast("Scan complete."))
      .catch((error) => showToast(error.message, true));
  });
}

bindEvents();
setIconState();
refreshSummary().catch((error) => showToast(error.message, true));
