from __future__ import annotations

from datetime import datetime
from pathlib import Path

from .comparison import count_at_risk_accounts
from .models import AccountRecord


def generate_report(
    accounts: list[AccountRecord],
    duplicate_groups: list[list[AccountRecord]],
    output_dir: Path,
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    filename_stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = output_dir / f"password_reuse_report_{filename_stamp}.txt"

    lines = [
        "Password Reuse Detection Report",
        "=" * 33,
        f"Generated at: {generated_at}",
        f"Total accounts scanned: {len(accounts)}",
        f"Duplicate password groups: {len(duplicate_groups)}",
        f"At-risk accounts: {count_at_risk_accounts(duplicate_groups)}",
        "",
    ]

    if not duplicate_groups:
        lines.append("Result: No password reuse detected.")
    else:
        lines.append("Result: Password reuse detected.")
        lines.append("")

        for group_number, group in enumerate(duplicate_groups, start=1):
            lines.append(f"Duplicate Group {group_number}")
            lines.append("-" * 17)
            for account in group:
                lines.append(f"- Service: {account.service} | Username: {account.username}")
            lines.append("")

    report_path.write_text("\n".join(lines), encoding="utf-8")
    return report_path
