from __future__ import annotations

import json
from pathlib import Path

from .models import AccountRecord


class AccountStore:
    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path

    def load(self) -> list[AccountRecord]:
        if not self.db_path.exists():
            return []

        with self.db_path.open("r", encoding="utf-8") as file:
            raw_records = json.load(file)

        return [AccountRecord.from_dict(record) for record in raw_records]

    def save(self, accounts: list[AccountRecord]) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self.db_path.open("w", encoding="utf-8") as file:
            json.dump([account.to_dict() for account in accounts], file, indent=2)

    def find_index(self, accounts: list[AccountRecord], service: str, username: str) -> int | None:
        service_key = service.casefold()
        username_key = username.casefold()

        for index, account in enumerate(accounts):
            if account.service.casefold() == service_key and account.username.casefold() == username_key:
                return index

        return None

    def upsert(self, account: AccountRecord) -> bool:
        accounts = self.load()
        existing_index = self.find_index(accounts, account.service, account.username)

        if existing_index is None:
            accounts.append(account)
            updated_existing = False
        else:
            original = accounts[existing_index]
            account.record_id = original.record_id
            account.created_at = original.created_at
            accounts[existing_index] = account
            updated_existing = True

        self.save(accounts)
        return updated_existing

    def delete(self, record_id: str) -> bool:
        accounts = self.load()
        remaining_accounts = [account for account in accounts if account.record_id != record_id]

        if len(remaining_accounts) == len(accounts):
            return False

        self.save(remaining_accounts)
        return True
