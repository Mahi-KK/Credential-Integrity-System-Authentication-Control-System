from __future__ import annotations

from collections import defaultdict

from .models import AccountRecord


def detect_duplicate_passwords(accounts: list[AccountRecord]) -> list[list[AccountRecord]]:
    grouped: dict[str, list[AccountRecord]] = defaultdict(list)

    for account in accounts:
        grouped[account.reuse_fingerprint].append(account)

    duplicates = [group for group in grouped.values() if len(group) > 1]
    return [
        sorted(group, key=lambda account: (account.service.casefold(), account.username.casefold()))
        for group in duplicates
    ]


def count_at_risk_accounts(duplicate_groups: list[list[AccountRecord]]) -> int:
    return sum(len(group) for group in duplicate_groups)
