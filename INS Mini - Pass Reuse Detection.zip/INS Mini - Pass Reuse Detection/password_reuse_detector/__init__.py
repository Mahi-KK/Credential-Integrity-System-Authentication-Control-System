"""Password reuse detection mini project."""

__version__ = "1.0.0"
