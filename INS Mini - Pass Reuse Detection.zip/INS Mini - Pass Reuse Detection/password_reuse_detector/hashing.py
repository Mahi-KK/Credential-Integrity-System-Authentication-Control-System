from __future__ import annotations

import hashlib
import hmac
import secrets
from pathlib import Path

DEFAULT_ITERATIONS = 200_000
HASH_NAME = "sha256"
SALT_BYTES = 16
SECRET_BYTES = 32


def load_or_create_secret(secret_path: Path) -> bytes:
    secret_path.parent.mkdir(parents=True, exist_ok=True)

    if secret_path.exists():
        secret_hex = secret_path.read_text(encoding="utf-8").strip()
        return bytes.fromhex(secret_hex)

    secret = secrets.token_bytes(SECRET_BYTES)
    secret_path.write_text(secret.hex(), encoding="utf-8")
    return secret


def hash_password(password: str, iterations: int = DEFAULT_ITERATIONS) -> tuple[str, str]:
    salt = secrets.token_bytes(SALT_BYTES)
    digest = hashlib.pbkdf2_hmac(
        HASH_NAME,
        password.encode("utf-8"),
        salt,
        iterations,
    )
    return salt.hex(), digest.hex()


def verify_password(password: str, salt_hex: str, expected_hash_hex: str, iterations: int) -> bool:
    digest = hashlib.pbkdf2_hmac(
        HASH_NAME,
        password.encode("utf-8"),
        bytes.fromhex(salt_hex),
        iterations,
    )
    return secrets.compare_digest(digest.hex(), expected_hash_hex)


def reuse_fingerprint(password: str, secret: bytes) -> str:
    return hmac.new(secret, password.encode("utf-8"), hashlib.sha256).hexdigest()
