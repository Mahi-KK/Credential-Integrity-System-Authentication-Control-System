from __future__ import annotations

from datetime import datetime
from getpass import getpass
from pathlib import Path
from uuid import uuid4

from .comparison import detect_duplicate_passwords
from .hashing import DEFAULT_ITERATIONS, hash_password, load_or_create_secret, reuse_fingerprint
from .models import AccountRecord
from .report import generate_report
from .storage import AccountStore

DATA_DIR = Path("data")
REPORT_DIR = Path("reports")
DB_PATH = DATA_DIR / "accounts.json"
SECRET_PATH = DATA_DIR / "reuse_secret.key"


def build_account_record(service: str, username: str, password: str, secret: bytes) -> AccountRecord:
    now = datetime.now().isoformat(timespec="seconds")
    salt, password_hash = hash_password(password)

    return AccountRecord(
        record_id=str(uuid4()),
        service=service.strip(),
        username=username.strip(),
        password_hash=password_hash,
        salt=salt,
        iterations=DEFAULT_ITERATIONS,
        reuse_fingerprint=reuse_fingerprint(password, secret),
        created_at=now,
        updated_at=now,
    )


def prompt_required(label: str) -> str:
    while True:
        value = input(label).strip()
        if value:
            return value
        print("Value cannot be empty.")


def add_account(store: AccountStore, secret: bytes) -> None:
    print("\nAccount Entry")
    print("-" * 13)
    service = prompt_required("Service name: ")
    username = prompt_required("Username/email: ")
    password = getpass("Password: ")

    if not password:
        print("Password cannot be empty.")
        return

    account = build_account_record(service, username, password, secret)
    updated_existing = store.upsert(account)

    if updated_existing:
        print("Existing account updated with a new password hash.")
    else:
        print("Account password record stored.")


def list_accounts(store: AccountStore) -> None:
    accounts = store.load()

    print("\nStored Accounts")
    print("-" * 15)

    if not accounts:
        print("No account records yet.")
        return

    for index, account in enumerate(accounts, start=1):
        print(f"{index}. {account.display_name} | added: {account.created_at}")


def show_duplicates(store: AccountStore) -> list[list[AccountRecord]]:
    accounts = store.load()
    duplicate_groups = detect_duplicate_passwords(accounts)

    print("\nPassword Reuse Check")
    print("-" * 20)

    if not accounts:
        print("No account records to scan.")
        return []

    if not duplicate_groups:
        print("No password reuse detected.")
        return []

    print(f"Found {len(duplicate_groups)} duplicate password group(s).")
    for group_number, group in enumerate(duplicate_groups, start=1):
        print(f"\nDuplicate Group {group_number}")
        for account in group:
            print(f"- {account.display_name}")

    return duplicate_groups


def write_report(store: AccountStore) -> None:
    accounts = store.load()
    duplicate_groups = detect_duplicate_passwords(accounts)
    report_path = generate_report(accounts, duplicate_groups, REPORT_DIR)
    print(f"\nReport generated: {report_path.resolve()}")


def print_menu() -> None:
    print("\nPassword Reuse Detection System")
    print("=" * 31)
    print("1. Store account password")
    print("2. View stored accounts")
    print("3. Compare hashes and detect duplicates")
    print("4. Generate report")
    print("5. Exit")


def main() -> None:
    secret = load_or_create_secret(SECRET_PATH)
    store = AccountStore(DB_PATH)

    while True:
        print_menu()
        choice = input("Choose an option: ").strip()

        if choice == "1":
            add_account(store, secret)
        elif choice == "2":
            list_accounts(store)
        elif choice == "3":
            show_duplicates(store)
        elif choice == "4":
            write_report(store)
        elif choice == "5":
            print("Goodbye.")
            break
        else:
            print("Invalid choice. Please select 1-5.")
