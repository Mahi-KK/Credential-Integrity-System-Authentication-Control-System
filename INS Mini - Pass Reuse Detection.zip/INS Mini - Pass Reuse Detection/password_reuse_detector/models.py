from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(slots=True)
class AccountRecord:
    record_id: str
    service: str
    username: str
    password_hash: str
    salt: str
    iterations: int
    reuse_fingerprint: str
    created_at: str
    updated_at: str

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AccountRecord":
        return cls(
            record_id=str(data["record_id"]),
            service=str(data["service"]),
            username=str(data["username"]),
            password_hash=str(data["password_hash"]),
            salt=str(data["salt"]),
            iterations=int(data["iterations"]),
            reuse_fingerprint=str(data["reuse_fingerprint"]),
            created_at=str(data["created_at"]),
            updated_at=str(data["updated_at"]),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @property
    def display_name(self) -> str:
        return f"{self.service} ({self.username})"
