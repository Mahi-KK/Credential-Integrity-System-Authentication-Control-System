from __future__ import annotations

import argparse
import json
import mimetypes
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

from .cli import DB_PATH, REPORT_DIR, SECRET_PATH, build_account_record
from .comparison import count_at_risk_accounts, detect_duplicate_passwords
from .hashing import load_or_create_secret
from .models import AccountRecord
from .report import generate_report
from .storage import AccountStore

PROJECT_ROOT = Path(__file__).resolve().parent.parent
WEB_ROOT = PROJECT_ROOT / "web"


def account_to_public_dict(account: AccountRecord, at_risk: bool = False) -> dict[str, Any]:
    return {
        "recordId": account.record_id,
        "service": account.service,
        "username": account.username,
        "hashPreview": f"{account.password_hash[:12]}...{account.password_hash[-8:]}",
        "createdAt": account.created_at,
        "updatedAt": account.updated_at,
        "atRisk": at_risk,
    }


def build_summary(accounts: list[AccountRecord]) -> dict[str, Any]:
    duplicate_groups = detect_duplicate_passwords(accounts)
    at_risk_ids = {
        account.record_id
        for group in duplicate_groups
        for account in group
    }

    return {
        "metrics": {
            "totalAccounts": len(accounts),
            "uniquePasswords": len({account.reuse_fingerprint for account in accounts}),
            "duplicateGroups": len(duplicate_groups),
            "atRiskAccounts": count_at_risk_accounts(duplicate_groups),
        },
        "accounts": [
            account_to_public_dict(account, account.record_id in at_risk_ids)
            for account in sorted(accounts, key=lambda item: (item.service.casefold(), item.username.casefold()))
        ],
        "duplicateGroups": [
            {
                "groupNumber": index,
                "accounts": [account_to_public_dict(account, True) for account in group],
            }
            for index, group in enumerate(duplicate_groups, start=1)
        ],
    }


class PasswordReuseRequestHandler(BaseHTTPRequestHandler):
    store = AccountStore(DB_PATH)
    secret = load_or_create_secret(SECRET_PATH)

    def log_message(self, format: str, *args: Any) -> None:
        return

    def do_GET(self) -> None:
        path = urlparse(self.path).path

        if path == "/" or path == "/index.html":
            self.serve_static_file(WEB_ROOT / "index.html")
            return

        if path.startswith("/static/"):
            static_path = WEB_ROOT / unquote(path.lstrip("/"))
            self.serve_static_file(static_path)
            return

        if path == "/api/summary":
            self.send_json(build_summary(self.store.load()))
            return

        if path.startswith("/api/reports/"):
            report_name = Path(unquote(path.removeprefix("/api/reports/"))).name
            self.serve_report_file(REPORT_DIR / report_name)
            return

        self.send_error(HTTPStatus.NOT_FOUND, "Route not found")

    def do_POST(self) -> None:
        path = urlparse(self.path).path

        if path == "/api/accounts":
            self.create_account()
            return

        if path == "/api/reports":
            self.create_report()
            return

        self.send_error(HTTPStatus.NOT_FOUND, "Route not found")

    def do_DELETE(self) -> None:
        path = urlparse(self.path).path

        if path.startswith("/api/accounts/"):
            record_id = unquote(path.removeprefix("/api/accounts/"))
            deleted = self.store.delete(record_id)

            if not deleted:
                self.send_json({"error": "Account record was not found."}, HTTPStatus.NOT_FOUND)
                return

            self.send_json({"deleted": True, "summary": build_summary(self.store.load())})
            return

        self.send_error(HTTPStatus.NOT_FOUND, "Route not found")

    def create_account(self) -> None:
        payload = self.read_json_body()
        service = str(payload.get("service", "")).strip()
        username = str(payload.get("username", "")).strip()
        password = str(payload.get("password", ""))

        if not service or not username or not password:
            self.send_json(
                {"error": "Service, username, and password are required."},
                HTTPStatus.BAD_REQUEST,
            )
            return

        account = build_account_record(service, username, password, self.secret)
        updated_existing = self.store.upsert(account)
        status = HTTPStatus.OK if updated_existing else HTTPStatus.CREATED

        self.send_json(
            {
                "updated": updated_existing,
                "message": "Account updated." if updated_existing else "Account stored.",
                "summary": build_summary(self.store.load()),
            },
            status,
        )

    def create_report(self) -> None:
        accounts = self.store.load()
        duplicate_groups = detect_duplicate_passwords(accounts)
        report_path = generate_report(accounts, duplicate_groups, REPORT_DIR)

        self.send_json(
            {
                "fileName": report_path.name,
                "downloadUrl": f"/api/reports/{report_path.name}",
                "preview": report_path.read_text(encoding="utf-8"),
            }
        )

    def read_json_body(self) -> dict[str, Any]:
        content_length = int(self.headers.get("Content-Length", "0"))
        if content_length == 0:
            return {}

        raw_body = self.rfile.read(content_length).decode("utf-8")
        try:
            data = json.loads(raw_body)
        except json.JSONDecodeError:
            return {}

        return data if isinstance(data, dict) else {}

    def send_json(self, payload: dict[str, Any], status: HTTPStatus = HTTPStatus.OK) -> None:
        encoded = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def serve_static_file(self, path: Path) -> None:
        resolved_path = path.resolve()
        if WEB_ROOT.resolve() not in [resolved_path, *resolved_path.parents] or not resolved_path.is_file():
            self.send_error(HTTPStatus.NOT_FOUND, "File not found")
            return

        self.send_file(resolved_path)

    def serve_report_file(self, path: Path) -> None:
        resolved_path = path.resolve()
        report_root = REPORT_DIR.resolve()

        if report_root not in [resolved_path, *resolved_path.parents] or not resolved_path.is_file():
            self.send_error(HTTPStatus.NOT_FOUND, "Report not found")
            return

        self.send_file(
            resolved_path,
            content_type="text/plain; charset=utf-8",
            attachment_name=resolved_path.name,
        )

    def send_file(
        self,
        path: Path,
        content_type: str | None = None,
        attachment_name: str | None = None,
    ) -> None:
        file_bytes = path.read_bytes()
        guessed_type = content_type or mimetypes.guess_type(path.name)[0] or "application/octet-stream"

        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", guessed_type)
        self.send_header("Content-Length", str(len(file_bytes)))
        if attachment_name:
            self.send_header("Content-Disposition", f'attachment; filename="{attachment_name}"')
        self.end_headers()
        self.wfile.write(file_bytes)


def run_server(host: str = "127.0.0.1", port: int = 8000) -> None:
    server = ThreadingHTTPServer((host, port), PasswordReuseRequestHandler)
    print(f"Password Reuse Detection UI running at http://{host}:{port}")
    print("Press Ctrl+C to stop.")
    server.serve_forever()


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Password Reuse Detection web UI.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", default=8000, type=int)
    args = parser.parse_args()
    run_server(args.host, args.port)


if __name__ == "__main__":
    main()
