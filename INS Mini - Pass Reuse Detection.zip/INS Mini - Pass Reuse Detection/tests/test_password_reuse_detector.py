from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from password_reuse_detector.cli import build_account_record
from password_reuse_detector.comparison import count_at_risk_accounts, detect_duplicate_passwords
from password_reuse_detector.hashing import hash_password, reuse_fingerprint
from password_reuse_detector.report import generate_report
from password_reuse_detector.web import build_summary


class PasswordReuseDetectorTests(unittest.TestCase):
    def test_same_password_has_different_salted_hash_but_same_fingerprint(self) -> None:
        secret = b"test-secret-for-hmac"

        salt_one, hash_one = hash_password("SamePassword123")
        salt_two, hash_two = hash_password("SamePassword123")

        self.assertNotEqual(salt_one, salt_two)
        self.assertNotEqual(hash_one, hash_two)
        self.assertEqual(
            reuse_fingerprint("SamePassword123", secret),
            reuse_fingerprint("SamePassword123", secret),
        )

    def test_detect_duplicate_password_group(self) -> None:
        secret = b"test-secret-for-hmac"
        accounts = [
            build_account_record("Gmail", "alice@example.com", "ReuseMe123", secret),
            build_account_record("GitHub", "alice", "ReuseMe123", secret),
            build_account_record("Bank", "alice", "Different123", secret),
        ]

        duplicate_groups = detect_duplicate_passwords(accounts)

        self.assertEqual(1, len(duplicate_groups))
        self.assertEqual(2, len(duplicate_groups[0]))
        self.assertEqual(2, count_at_risk_accounts(duplicate_groups))

    def test_generate_report_file(self) -> None:
        secret = b"test-secret-for-hmac"
        accounts = [
            build_account_record("Gmail", "alice@example.com", "ReuseMe123", secret),
            build_account_record("GitHub", "alice", "ReuseMe123", secret),
        ]
        duplicate_groups = detect_duplicate_passwords(accounts)

        with tempfile.TemporaryDirectory() as temp_dir:
            report_path = generate_report(accounts, duplicate_groups, Path(temp_dir))
            report_text = report_path.read_text(encoding="utf-8")

        self.assertIn("Password Reuse Detection Report", report_text)
        self.assertIn("Duplicate Group 1", report_text)
        self.assertIn("At-risk accounts: 2", report_text)

    def test_build_summary_for_ui(self) -> None:
        secret = b"test-secret-for-hmac"
        accounts = [
            build_account_record("Gmail", "alice@example.com", "ReuseMe123", secret),
            build_account_record("GitHub", "alice", "ReuseMe123", secret),
            build_account_record("Bank", "alice", "Different123", secret),
        ]

        summary = build_summary(accounts)

        self.assertEqual(3, summary["metrics"]["totalAccounts"])
        self.assertEqual(2, summary["metrics"]["uniquePasswords"])
        self.assertEqual(1, summary["metrics"]["duplicateGroups"])
        self.assertEqual(2, summary["metrics"]["atRiskAccounts"])
        self.assertEqual(3, len(summary["accounts"]))
        self.assertEqual(1, len(summary["duplicateGroups"]))


if __name__ == "__main__":
    unittest.main()
