from __future__ import annotations

from django.contrib import admin

from .models import AccountPasswordRecord, PasswordReuseReport


@admin.register(AccountPasswordRecord)
class AccountPasswordRecordAdmin(admin.ModelAdmin):
    list_display = ("service", "account_identifier", "user", "updated_at")
    list_filter = ("service", "updated_at")
    search_fields = ("service", "account_identifier", "user__username")
    readonly_fields = ("password_hash", "salt", "iterations", "reuse_fingerprint", "created_at", "updated_at")


@admin.register(PasswordReuseReport)
class PasswordReuseReportAdmin(admin.ModelAdmin):
    list_display = ("user", "total_accounts", "duplicate_groups", "at_risk_accounts", "created_at")
    list_filter = ("created_at",)
    search_fields = ("user__username", "body")
