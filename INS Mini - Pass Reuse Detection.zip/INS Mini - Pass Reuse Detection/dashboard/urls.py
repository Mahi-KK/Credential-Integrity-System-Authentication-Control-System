from __future__ import annotations

from django.urls import path

from . import views

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("accounts/save/", views.save_account, name="save_account"),
    path("accounts/<int:record_id>/delete/", views.delete_account, name="delete_account"),
    path("scan/", views.scan_passwords, name="scan_passwords"),
    path("reports/generate/", views.generate_report, name="generate_report"),
    path("reports/<int:report_id>/", views.report_detail, name="report_detail"),
    path("reports/<int:report_id>/download/", views.download_report, name="download_report"),
]
