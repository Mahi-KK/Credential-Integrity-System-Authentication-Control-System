"""Django dashboard app for password reuse detection."""
