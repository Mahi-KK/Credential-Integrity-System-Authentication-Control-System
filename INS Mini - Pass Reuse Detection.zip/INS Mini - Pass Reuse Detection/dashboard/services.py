from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

from django.contrib.auth.models import AbstractUser
from django.db.models import QuerySet
from django.utils import timezone

from .models import AccountPasswordRecord, PasswordReuseReport


@dataclass(frozen=True)
class DashboardMetrics:
    total_accounts: int
    unique_passwords: int
    duplicate_groups: int
    at_risk_accounts: int


def user_records(user: AbstractUser) -> QuerySet[AccountPasswordRecord]:
    return AccountPasswordRecord.objects.filter(user=user).order_by("service", "account_identifier")


def duplicate_groups_for_user(user: AbstractUser) -> list[list[AccountPasswordRecord]]:
    grouped: dict[str, list[AccountPasswordRecord]] = defaultdict(list)

    for record in user_records(user):
        grouped[record.reuse_fingerprint].append(record)

    groups = [records for records in grouped.values() if len(records) > 1]
    return [
        sorted(records, key=lambda item: (item.service.casefold(), item.account_identifier.casefold()))
        for records in groups
    ]


def metrics_for_user(user: AbstractUser) -> DashboardMetrics:
    records = list(user_records(user))
    duplicate_groups = duplicate_groups_for_user(user)

    return DashboardMetrics(
        total_accounts=len(records),
        unique_passwords=len({record.reuse_fingerprint for record in records}),
        duplicate_groups=len(duplicate_groups),
        at_risk_accounts=sum(len(group) for group in duplicate_groups),
    )


def at_risk_record_ids(user: AbstractUser) -> set[int]:
    return {
        record.id
        for group in duplicate_groups_for_user(user)
        for record in group
    }


def build_report_body(user: AbstractUser) -> tuple[str, DashboardMetrics]:
    metrics = metrics_for_user(user)
    duplicate_groups = duplicate_groups_for_user(user)
    generated_at = timezone.localtime().strftime("%Y-%m-%d %H:%M:%S")

    lines = [
        "Password Reuse Detection Report",
        "=" * 33,
        f"Generated at: {generated_at}",
        f"Generated for: {user.username}",
        f"Total accounts scanned: {metrics.total_accounts}",
        f"Unique passwords: {metrics.unique_passwords}",
        f"Duplicate password groups: {metrics.duplicate_groups}",
        f"At-risk accounts: {metrics.at_risk_accounts}",
        "",
    ]

    if not duplicate_groups:
        lines.append("Result: No password reuse detected.")
    else:
        lines.append("Result: Password reuse detected.")
        lines.append("")
        for index, group in enumerate(duplicate_groups, start=1):
            lines.append(f"Duplicate Group {index}")
            lines.append("-" * 17)
            for record in group:
                lines.append(f"- Service: {record.service} | Username: {record.account_identifier}")
            lines.append("")

    return "\n".join(lines), metrics


def create_report(user: AbstractUser) -> PasswordReuseReport:
    body, metrics = build_report_body(user)
    return PasswordReuseReport.objects.create(
        user=user,
        total_accounts=metrics.total_accounts,
        unique_passwords=metrics.unique_passwords,
        duplicate_groups=metrics.duplicate_groups,
        at_risk_accounts=metrics.at_risk_accounts,
        body=body,
    )
