from __future__ import annotations

import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="PasswordReuseReport",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("total_accounts", models.PositiveIntegerField(default=0)),
                ("unique_passwords", models.PositiveIntegerField(default=0)),
                ("duplicate_groups", models.PositiveIntegerField(default=0)),
                ("at_risk_accounts", models.PositiveIntegerField(default=0)),
                ("body", models.TextField()),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                (
                    "user",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="reuse_reports",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={"ordering": ["-created_at"]},
        ),
        migrations.CreateModel(
            name="AccountPasswordRecord",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("service", models.CharField(max_length=80)),
                ("account_identifier", models.CharField(max_length=160, verbose_name="username or email")),
                ("password_hash", models.CharField(max_length=128)),
                ("salt", models.CharField(max_length=64)),
                ("iterations", models.PositiveIntegerField(default=200000)),
                ("reuse_fingerprint", models.CharField(db_index=True, max_length=64)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                (
                    "user",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="password_records",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={"ordering": ["service", "account_identifier"]},
        ),
        migrations.AddConstraint(
            model_name="accountpasswordrecord",
            constraint=models.UniqueConstraint(
                fields=("user", "service", "account_identifier"),
                name="unique_account_record_per_user",
            ),
        ),
    ]
