from __future__ import annotations

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


BOOTSTRAP_INPUT = "form-control form-control-lg"


class AccountPasswordForm(forms.Form):
    service = forms.CharField(
        max_length=80,
        widget=forms.TextInput(attrs={"class": BOOTSTRAP_INPUT, "placeholder": "GitHub"}),
    )
    account_identifier = forms.CharField(
        label="Username or email",
        max_length=160,
        widget=forms.TextInput(attrs={"class": BOOTSTRAP_INPUT, "placeholder": "alex@example.com"}),
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={"class": BOOTSTRAP_INPUT, "placeholder": "Enter account password"}),
    )


class RegisterForm(UserCreationForm):
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={"class": BOOTSTRAP_INPUT, "placeholder": "name@example.com"}),
    )

    class Meta:
        model = User
        fields = ("username", "email", "password1", "password2")
        widgets = {
            "username": forms.TextInput(attrs={"class": BOOTSTRAP_INPUT, "placeholder": "Choose a username"}),
        }

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        for field_name in ("password1", "password2"):
            self.fields[field_name].widget.attrs.update(
                {"class": BOOTSTRAP_INPUT, "placeholder": self.fields[field_name].label}
            )

    def clean_username(self) -> str:
        username = self.cleaned_data["username"].strip()
        if User.objects.filter(username__iexact=username).exists():
            raise forms.ValidationError("This username is already taken. Please log in or choose another username.")
        return username

    def save(self, commit: bool = True) -> User:
        user = super().save(commit=False)
        user.email = self.cleaned_data["email"]
        if commit:
            user.save()
        return user
