from __future__ import annotations

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from .models import AccountPasswordRecord, PasswordReuseReport
from .services import duplicate_groups_for_user, metrics_for_user


class DashboardFlowTests(TestCase):
    def setUp(self) -> None:
        self.user = User.objects.create_user(username="demo", password="DemoPass12345")
        self.client.force_login(self.user)

    def test_account_reuse_pipeline_and_report(self) -> None:
        for service, identifier in (("Gmail", "demo@example.com"), ("GitHub", "demo-user")):
            response = self.client.post(
                reverse("save_account"),
                {
                    "service": service,
                    "account_identifier": identifier,
                    "password": "SamePassword123",
                },
            )
            self.assertEqual(302, response.status_code)

        self.assertEqual(2, AccountPasswordRecord.objects.count())
        self.assertEqual(1, len(duplicate_groups_for_user(self.user)))

        metrics = metrics_for_user(self.user)
        self.assertEqual(2, metrics.total_accounts)
        self.assertEqual(1, metrics.unique_passwords)
        self.assertEqual(1, metrics.duplicate_groups)
        self.assertEqual(2, metrics.at_risk_accounts)

        response = self.client.post(reverse("generate_report"))
        self.assertEqual(302, response.status_code)
        self.assertEqual(1, PasswordReuseReport.objects.count())
        self.assertIn("Password reuse detected", PasswordReuseReport.objects.first().body)

    def test_dashboard_requires_login(self) -> None:
        self.client.logout()
        response = self.client.get(reverse("dashboard"))
        self.assertEqual(302, response.status_code)
        self.assertIn(reverse("login"), response["Location"])

    def test_duplicate_username_registration_returns_form_error(self) -> None:
        self.client.logout()
        response = self.client.post(
            reverse("register"),
            {
                "username": "demo",
                "email": "another@example.com",
                "password1": "DemoPass12345",
                "password2": "DemoPass12345",
            },
        )

        self.assertEqual(200, response.status_code)
        self.assertContains(response, "This username is already taken")
