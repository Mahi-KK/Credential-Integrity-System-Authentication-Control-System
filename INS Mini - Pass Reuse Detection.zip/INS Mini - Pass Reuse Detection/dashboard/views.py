from __future__ import annotations

from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .forms import AccountPasswordForm, RegisterForm
from .models import AccountPasswordRecord, PasswordReuseReport
from .services import at_risk_record_ids, create_report, duplicate_groups_for_user, metrics_for_user, user_records


def register(request):
    if request.user.is_authenticated:
        return redirect("dashboard")

    form = RegisterForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        try:
            user = form.save()
        except IntegrityError:
            form.add_error("username", "This username is already taken. Please choose another username.")
            return render(request, "registration/register.html", {"form": form})
        login(request, user)
        messages.success(request, "Account created. Your dashboard is ready.")
        return redirect("dashboard")

    return render(request, "registration/register.html", {"form": form})


@login_required
def dashboard(request):
    records = list(user_records(request.user))
    risk_ids = at_risk_record_ids(request.user)
    latest_report = PasswordReuseReport.objects.filter(user=request.user).first()

    return render(
        request,
        "dashboard/dashboard.html",
        {
            "form": AccountPasswordForm(),
            "metrics": metrics_for_user(request.user),
            "records": records,
            "risk_ids": risk_ids,
            "duplicate_groups": duplicate_groups_for_user(request.user),
            "latest_report": latest_report,
            "recent_reports": PasswordReuseReport.objects.filter(user=request.user)[:5],
        },
    )


@login_required
@require_POST
def save_account(request):
    form = AccountPasswordForm(request.POST)
    if not form.is_valid():
        messages.error(request, "Please complete all account fields.")
        return redirect("dashboard")

    service = form.cleaned_data["service"].strip()
    account_identifier = form.cleaned_data["account_identifier"].strip()
    password = form.cleaned_data["password"]
    record, created = AccountPasswordRecord.objects.get_or_create(
        user=request.user,
        service=service,
        account_identifier=account_identifier,
        defaults={"password_hash": "", "salt": "", "reuse_fingerprint": ""},
    )
    record.set_plain_password(password)
    record.save()

    if created:
        messages.success(request, f"{service} record stored and hashed.")
    else:
        messages.success(request, f"{service} record updated with a new password hash.")

    return redirect("dashboard")


@login_required
@require_POST
def scan_passwords(request):
    metrics = metrics_for_user(request.user)
    if metrics.at_risk_accounts:
        messages.warning(request, f"Scan complete: {metrics.at_risk_accounts} account(s) reuse a password.")
    else:
        messages.success(request, "Scan complete: no password reuse detected.")
    return redirect("dashboard")


@login_required
@require_POST
def delete_account(request, record_id: int):
    record = get_object_or_404(AccountPasswordRecord, id=record_id, user=request.user)
    service = record.service
    record.delete()
    messages.success(request, f"{service} record deleted.")
    return redirect("dashboard")


@login_required
@require_POST
def generate_report(request):
    report = create_report(request.user)
    messages.success(request, "Report generated successfully.")
    return redirect("report_detail", report_id=report.id)


@login_required
def report_detail(request, report_id: int):
    report = get_object_or_404(PasswordReuseReport, id=report_id, user=request.user)
    return render(request, "dashboard/report_detail.html", {"report": report})


@login_required
def download_report(request, report_id: int):
    report = get_object_or_404(PasswordReuseReport, id=report_id, user=request.user)
    if not report.created_at:
        raise Http404

    filename = f"password_reuse_report_{report.created_at:%Y%m%d_%H%M%S}.txt"
    response = HttpResponse(report.body, content_type="text/plain; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    return response
