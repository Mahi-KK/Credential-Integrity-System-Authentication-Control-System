from __future__ import annotations

from pathlib import Path

from django.conf import settings
from django.db import models

from password_reuse_detector.hashing import DEFAULT_ITERATIONS, hash_password, load_or_create_secret, reuse_fingerprint


class AccountPasswordRecord(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="password_records")
    service = models.CharField(max_length=80)
    account_identifier = models.CharField("username or email", max_length=160)
    password_hash = models.CharField(max_length=128)
    salt = models.CharField(max_length=64)
    iterations = models.PositiveIntegerField(default=DEFAULT_ITERATIONS)
    reuse_fingerprint = models.CharField(max_length=64, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["user", "service", "account_identifier"],
                name="unique_account_record_per_user",
            )
        ]
        ordering = ["service", "account_identifier"]

    def __str__(self) -> str:
        return f"{self.service} ({self.account_identifier})"

    def set_plain_password(self, password: str) -> None:
        secret = load_or_create_secret(Path(settings.REUSE_SECRET_PATH))
        salt, password_hash = hash_password(password)
        self.salt = salt
        self.password_hash = password_hash
        self.iterations = DEFAULT_ITERATIONS
        self.reuse_fingerprint = reuse_fingerprint(password, secret)

    @property
    def hash_preview(self) -> str:
        return f"{self.password_hash[:12]}...{self.password_hash[-8:]}"


class PasswordReuseReport(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="reuse_reports")
    total_accounts = models.PositiveIntegerField(default=0)
    unique_passwords = models.PositiveIntegerField(default=0)
    duplicate_groups = models.PositiveIntegerField(default=0)
    at_risk_accounts = models.PositiveIntegerField(default=0)
    body = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self) -> str:
        return f"Report {self.created_at:%Y-%m-%d %H:%M}"
